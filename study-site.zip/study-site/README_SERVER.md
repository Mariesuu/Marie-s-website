Mi Corazón — 简易 AI 判分后端

位置: `study-site/server`

快速开始：

1. 进入目录：

```bash
cd study-site/server
```

2. 安装依赖：

```bash
npm install
```

3. 可选：将 `.env.example` 复制为 `.env` 并填写 `OPENAI_API_KEY`（如果想调用 OpenAI）

4. 启动：

```bash
npm start
```

接口说明：
- `POST /api/ai/score`：请求体 JSON，字段：`type` (`writing` 或 `speaking`)、`level`、`prompt`、`text`（写作）或 `transcript`（口语）。
- 返回 JSON：`{score: number, feedback: string}`。

说明：本后端默认返回模拟分数；配置 `OPENAI_API_KEY` 后会调用 OpenAI 完成更真实的评分与建议。