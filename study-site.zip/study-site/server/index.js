const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Serve static frontend from parent folder (study-site)
app.use(express.static(path.join(__dirname, '..')));

// Explicit root route to ensure visiting http://localhost:3000 returns index.html
app.get('/', (req, res) => {
  console.log('GET / -> serving index.html from', path.join(__dirname, '..', 'index.html'));
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// Simple health
app.get('/api/health', (req, res) => res.json({ok: true}));

// /api/ai/score
// Expects JSON body: { type: 'speaking'|'writing', level: 'A2'|'B1'|'B2'|'C1', prompt, transcript?|text }
// This endpoint provides a mocked scoring by default. If you set OPENAI_API_KEY in .env, it will call OpenAI's completions (or other model) to generate a score and feedback.
app.post('/api/ai/score', async (req, res) => {
  const body = req.body || {};
  const {type, level, prompt} = body;

  // Basic validation
  if(!type || !level) return res.status(400).json({error: 'missing type or level'});

  // If OPENAI_API_KEY provided, call OpenAI; otherwise return mocked result
  const key = process.env.OPENAI_API_KEY;
  if(!key){
    // simple heuristic scoring
    const score = type === 'writing' ? 8 : 6;
    const feedback = type === 'writing' ? 'Buen trabajo. Mejora: conectar frases con conectores y revisar tiempos verbales.' : '发音听得清楚，多练习连读与重音。';
    return res.json({score, feedback});
  }

  // If API key is present, call OpenAI (text-davinci-003 style prompt)
  try{
    const openaiUrl = process.env.OPENAI_API_URL || 'https://api.openai.com/v1/completions';
    const promptText = buildPromptForScoring(body);
    const r = await fetch(openaiUrl, {
      method: 'POST', headers: {
        'Content-Type': 'application/json', 'Authorization': `Bearer ${key}`
      },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'text-davinci-003', prompt: promptText, max_tokens: 200, temperature: 0.2 })
    });
    const j = await r.json();
    const text = (j.choices && j.choices[0] && j.choices[0].text) ? j.choices[0].text.trim() : JSON.stringify(j);
    // Expect model to return something like: SCORE:8\nFEEDBACK: ...
    const parsed = parseModelScore(text);
    return res.json(parsed);
  }catch(err){
    console.error('OpenAI call failed', err);
    return res.status(500).json({error: 'ai_error', detail: err.message});
  }
});

function buildPromptForScoring(body){
  const {type, level, prompt, text, transcript} = body;
  if(type === 'writing'){
    return `你是西班牙语考试评分老师。请基于DELE评分标准对以下作文进行0-10分打分，并给出简短修改建议。\n\n级别: ${level}\n题目: ${prompt}\n作文:\n${text}\n\n请以:\nSCORE: <0-10>\nFEEDBACK: <简短建议>\n的格式返回。`;
  }
  if(type === 'speaking'){
    return `你是西班牙语口语评分老师。对以下口语文本按发音、流利度、连贯性给0-10分，并给出简短建议。\n\n级别: ${level}\n题目: ${prompt}\n朗读/回答文本:\n${transcript}\n\n返回格式:\nSCORE: <0-10>\nFEEDBACK: <简短建议>`;
  }
  return '评分请求';
}

function parseModelScore(text){
  const mScore = text.match(/SCORE[:\s]*([0-9]+(?:\.[0-9]+)?)/i);
  const mFeedback = text.match(/FEEDBACK[:\s]*([\s\S]+)/i);
  const score = mScore ? parseFloat(mScore[1]) : null;
  const feedback = mFeedback ? mFeedback[1].trim() : text;
  return {score, feedback};
}

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('AI server running on port', port));
